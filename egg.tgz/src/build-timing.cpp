// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("build timing\n", stdout);
  return lionss_run_workload("build-timing");
}
