// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("icx build\n", stdout);
  return lionss_run_workload("icx-build");
}
